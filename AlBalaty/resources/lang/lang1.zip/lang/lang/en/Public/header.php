<?php

return [
    'home'              => 'Home',
    'about-us'          => 'About Us',
    'all-courses'       => 'All Courses',
    'my-courses'        => 'My Courses',
    'my-dashboard'      => 'My Dashboard',
    'dashboard'         => 'Dashboard',
    'login'             => 'Login',
    'sign-up'           => 'Sign Up',
    'logout'            => 'Logout',

];
