<?php

return [
    'welcome'               => 'Welcome to the Pm-Tricks Help Community',
    'search-something'      => 'Search Something ... ',
    'faq'                   => 'FAQ',
    'submit-review'         => 'Submit Review ',
    'comment'               => 'Comment',
    'submit'                => 'submit',
    'comment-here'          => 'Enter Your Comments here..',
    'reply'                 => 'Reply',
];
