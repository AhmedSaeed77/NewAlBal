<?php

return [
    'welcome'               => 'مرحبًا بك في مجتمع مساعدة Pm-Tricks',
    'search-something'      => 'البحث...',
    'faq'                   => 'الأسئلة الشائعة',
    'submit-review'         => 'إرسال تعليق',
    'comment'               => 'تعليق',
    'submit'                => 'ارسال',
    'comment-here'          => 'أدخل تعليقك  هنا .',
    'reply'                 => 'الرد',
];
