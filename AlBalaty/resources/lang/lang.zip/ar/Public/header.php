<?php

return [
    'home'              => 'الصفحة الرئيسية',
    'about-us'          => 'معلومات عنا',
    'all-courses'       => 'جميع الدورات',
    'my-courses'        => 'دوراتي',
    'my-dashboard'      => 'لوحة التحكم',
    'dashboard'         => 'لوحة التحكم',
    'login'             => 'تسجيل الدخول',
    'sign-up'           => 'سجل',
    'logout'            => 'تسجيل خروج',

];
