<?php

return [
    'active-courses'                => 'الدورات النشطة',
    'expired'                       => 'منتهية الصلاحية',
    'courses-available'             => 'الدورات المتاحة',
    'view'                          => 'عرض',
    'active-event'                  => 'الاحداث النشطة',
    'event-available'               => 'الاحداث المتاحة',
    'success'                       => 'نجاح',
    'fails'                         => 'فشل',
    'exam-analysis'                 => 'تحليل الامتحان',
    'certifications'                => 'الشهادات',
    'certification'                 => 'شهادة',
    'package'                       => 'دورة',
    'download'                      => 'تحميل',
    'close'                         => 'أغلق',
    'what-learn-next'               => 'ماذا نتعلم بعد ذلك',
    'recommended-you'               => 'موصى به لك',
    'view-all'                      => 'مشاهدة الكل',
    'hot'                           => 'جديد',
    'exam'                          => 'امتحان',
    'exams'                         => 'الامتحانات',
    'questions'                     => 'أسئلة',
    'lectures'                      => 'محاضرات',
    'hours'                         => 'ساعات',
    'online-sessions'               => 'جلسات تفاعلية عبر الإنترنت',
    'end-at'                        => 'تنتهي في',
    'study-material'                => 'المواد الدراسية',


];
