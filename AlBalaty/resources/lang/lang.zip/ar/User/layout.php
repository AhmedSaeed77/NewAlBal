<?php

return [
    'dashboard'                 => 'الوحة الرئيسية',
    'notifications'             => 'إشعارات',
    'messages'                  => 'الرسائل',
    'make-read'                 => 'ضع إشارة مقروء',
    'student'                   => 'طالب',
    'my-profile'                => 'ملفي الشخصي',
    'inbox'                     => 'صندوق الوارد',
    'night-mode'                => 'الوضع الليلي',
    'sign-out'                  => 'خروج',
    'my-courses'                => 'دوراتي',
    'flash-card'                => 'Flash Card',
    'study-plan'                => 'خطة دراسية',
    'study-material'            => 'المواد الدراسية',
    'exam-analytics'            => 'تحليلات الامتحان',
    'faq'                       => 'الأسئلة الشائعة',
    'feedback'                  => 'ردود الفعل',
    'content-is-protected'      => 'المحتوى محمي بموجب حقوق النشر الخاصة بـ PM-Tricks.com',
    'note'                      => 'ملحوظة',
    'action-description'        => 'هذا الإجراء غير مسموح به ، أي شخص يحاول مشاركة هذا المحتوى المحمي بشكل غير قانوني دون سؤال المؤلف سيواجه مشكلات قانونية.',
    'action-description2'       => 'بجانب ذلك سيتم تعطيل حسابه مدى الحياة',
    'click-go-back'             => 'الرجاء الضغط (العودة)',
    'go-back'                   => 'العودة',
    'right-statement'           => 'كل الحقوق محفوظة.',


];
