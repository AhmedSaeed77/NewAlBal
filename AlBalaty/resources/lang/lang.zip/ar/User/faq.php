<?php

return [
    'welcome'               => 'مرحبًا بك في مجتمع مساعدة Pm-Tricks',
    'search-something'      => 'البحث عن شيء ما ...',
    'faq'                   => 'الأسئلة الشائعة',
    'submit-review'         => 'إرسال تعليق',
    'comment'               => 'تعليق',
    'submit'                => 'ارسال',
    'comment-here'          => 'أدخل تعليقاتك هنا ..',
    'reply'                 => 'الرد',
];
