<?php

return [
    'my-courses'            => 'دوراتي',
    'exams'                 => 'الامتحانات',
    'all'                   => 'الكل',
    'expire-at'             => 'تنتهي في',
    'exam'                  => 'امتحان',
    'questions'             => 'أسئلة',
    'videos'                => 'فيديوهات',
    'lectures'              => 'محاضرات',
    'hours'                 => 'ساعات',
    'online-sessions'       => 'جلسات تفاعلية عبر الإنترنت',
    'end-at'                => 'ينتهي في',
    'time-table'            => 'الجدول الزمني',
    'date'                  => 'تاريخ',
    'from'                  => 'من',
    'to'                    => 'الي',
    'close'                 => 'أغلق',
    'view-event'            => 'عرض الحدث',
    'not-available'         => 'ليس متاح الأن.',
    'expired-courses'       => 'الدورات منتهية الصلاحية',
    'reset'                 => 'إعادة تعيين',
    'extend'                => 'تمديد',
    'packages-are-active'   => 'باقتك نشطة الآن!',
    

];
