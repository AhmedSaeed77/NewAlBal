<?php

return [
    'feedback'          => 'Feedback',
    'rating'            => 'Rating',
    '5stars'            => '5 Stars',
    '4stars'            => '4 Stars',
    '3stars'            => '3 Stars',
    '2stars'            => '2 Stars',
    '1stars'            => '1 Stars',
    'title'             => 'Title',
    'send'              => 'Send',
    'delete'            => 'Delete',
];

